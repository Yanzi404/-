package ����3�鿨ģ����;

/**
 * @author 14018
 *������
 */
class Constant {
	public static int wq4=4958;
	public static int wq3=11231;
	public static int sh4=7437;
	public static int sh3=33694;
	public static int jb=8536;
	public static int jy=17072;
	public static int js=1500;
	public static int jssp=2625;
	public static int cl=5875;


}
