package �ϰ˺���;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

import �ϰ˺���.Music;

class Hamburg implements ActionListener {
	Graphics g;
	static final Image cdf = new ImageIcon("images/������.png").getImage();
	static final Image fn = new ImageIcon("images/��².png").getImage();
	static final Image lgm = new ImageIcon("images/�ϸ���.png").getImage();
	static final Image mzz = new ImageIcon("images/��֭֭��.png").getImage();
	static final Image d = new ImageIcon("images/�׶�.png").getImage();
	static final Image ge = new ImageIcon("images/�Ƕ�.png").getImage();
	static final Image bypg = new ImageIcon("images/��Ѽƨ��.png").getImage();
	static final Image hlb = new ImageIcon("images/���ܱ�.png").getImage();
	static final Image bb = new ImageIcon("images/����.png").getImage();
	static final Image bd = new ImageIcon("images/�״�.png").getImage();
	static final Image hgs = new ImageIcon("images/�ƹ�˿.png").getImage();
	static final Image nm = new ImageIcon("images/����.png").getImage();
	
	int h = 530+d.getHeight(null);
	boolean start=false;

	public Hamburg() {

	}

	public void setG(Graphics g) {
		this.g = g;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == Window.but[0][0]) {
			new Music("D://Java//�ϰ˺���//music//������.mp3").start();
			h = h - cdf.getHeight(null);
			g.drawImage(cdf, 350, h, null);
		} else if (e.getSource() == Window.but[0][1]) {
			new Music("D://Java//�ϰ˺���//music//��².mp3").start();
			h = h - fn.getHeight(null);
			g.drawImage(fn, 350, h, null);
		} else if (e.getSource() == Window.but[0][2]) {
			new Music("D://Java//�ϰ˺���//music//�ϸ���.mp3").start();
			h = h - lgm.getHeight(null);
			g.drawImage(lgm, 350, h, null);
		} else if (e.getSource() == Window.but[0][3]) {
			new Music("D://Java//�ϰ˺���//music//��֭֭.mp3").start();
			h = h - mzz.getHeight(null);
			g.drawImage(mzz, 350, h, null);
		} else if (e.getSource() == Window.but[0][4]&&start==false) {//��
			new Music("D://Java//�ϰ˺���//music//С����.mp3").start();
			h = h - d.getHeight(null);
			g.drawImage(d, 350, h, null);
		} else if (e.getSource() == Window.but[0][5]) {
			new Music("D://Java//�ϰ˺���//music//�����в���.mp3").start();
			h = h - ge.getHeight(null);
			g.drawImage(ge, 350, h, null);
			h = 530+d.getHeight(null);
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}	
			Window.drawBg(g);
		} else if (e.getSource() == Window.but[1][0]) {
			new Music("D://Java//�ϰ˺���//music//��Ѽƨ��.mp3").start();
			h = h - bypg.getHeight(null);
			g.drawImage(bypg, 350, h, null);
		} else if (e.getSource() == Window.but[1][1]) {
			new Music("D://Java//�ϰ˺���//music//���ܲ�.mp3").start();
			h = h - hlb.getHeight(null);
			g.drawImage(hlb, 350, h, null);
		} else if (e.getSource() == Window.but[1][2]) {
			new Music("D://Java//�ϰ˺���//music//����.mp3").start();
			h = h - bb.getHeight(null);
			g.drawImage(bb, 350, h, null);
		} else if (e.getSource() == Window.but[1][3]) {
			new Music("D://Java//�ϰ˺���//music//�״�.mp3").start();
			h = h - bd.getHeight(null);
			g.drawImage(bd, 350, h, null);
		} else if (e.getSource() == Window.but[1][4]) {
			new Music("D://Java//�ϰ˺���//music//�ƹ�˿.mp3").start();
			h = h - hgs.getHeight(null);
			g.drawImage(hgs, 350, h, null);
		} else if (e.getSource() == Window.but[1][5]) {
			new Music("D://Java//�ϰ˺���//music//����.mp3").start();
			h = h - nm.getHeight(null);
			g.drawImage(nm, 350, h, null);
		}

	}

}
