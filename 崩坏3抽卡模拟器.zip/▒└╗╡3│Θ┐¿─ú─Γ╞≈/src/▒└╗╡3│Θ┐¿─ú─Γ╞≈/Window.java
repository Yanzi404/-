package ����3�鿨ģ����;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;

public class Window extends JPanel implements ActionListener {
	JFrame frame;
	JButton but1, but2, but3, but4, but5, but6;
	static JTextPane jta1 = new JTextPane(),jta2=new JTextPane();
	JScrollPane scr1,scr2;
	Font font=new Font("΢���ź�",Font.BOLD,20);

	public Window() {
		frame = new JFrame("����3�鿨ģ����");
		jta1.setEditable(true);
		frame.setSize(400, 400);
		frame.setLocation(400, 300);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(this);
		frame.setVisible(true);
		jta1.setFont(font);
		jta2.setFont(font);
		//jta.setLineWrap(true);
		scr1 = new JScrollPane(jta1,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scr2 = new JScrollPane(jta2,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		JTabbedPane tab = new JTabbedPane(JTabbedPane.TOP);
		this.add(tab);// �����ǩ��
		{
			JPanel pan1 = new JPanel();
			pan1.setPreferredSize(new Dimension(400, 340));
			tab.addTab("��׼����", pan1);// ���ñ�ǩ��
			pan1.setLayout(new BorderLayout());
			pan1.add(scr1);
			JPanel pan = new JPanel();
			pan.setPreferredSize(new Dimension(400, 50));// ����pan�Ĵ�С,�ٷ����·�
			pan1.add(pan, BorderLayout.SOUTH);
			pan.setLayout(new GridLayout(1, 2, 3, 3));
			but1 = new JButton("��һ��");
			but2 = new JButton("��ʮ��");
			pan.add(but1);
			pan.add(but2);
			but1.addActionListener(this);
			but2.addActionListener(this);
		}
		{
			JPanel pan1 = new JPanel();
			pan1.setPreferredSize(new Dimension(400, 340));
			tab.addTab("���䲹��", pan1);// ���ñ�ǩ��
			pan1.setLayout(new BorderLayout());
			pan1.add(scr2);
			JPanel pan = new JPanel();
			pan.setPreferredSize(new Dimension(400, 50));// ����pan�Ĵ�С,�ٷ����·�
			pan1.add(pan, BorderLayout.SOUTH);
			pan.setLayout(new GridLayout(1, 2, 3, 3));
			but3 = new JButton("��һ��");
			but4 = new JButton("��ʮ��");
			pan.add(but3);
			pan.add(but4);
			but3.addActionListener(this);
			but4.addActionListener(this);
		}

	}

	public static void main(String[] args) {
		new Window();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == but1) {
			new GameRandom1(1);
		}
		if (e.getSource() == but2) {
			new GameRandom1(10);
		}
		if (e.getSource() == but3) {
			new GameRandom2(1);
		}
		if (e.getSource() == but4) {
			new GameRandom2(10);
		}

	}

}
